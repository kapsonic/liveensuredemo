# -----------------------------------------
# LIVEENSURE(R) AUTHENTICATION v5 for PYTHON
# -----------------------------------------
# (c) 2015-2016 All Rights Reserved.
# This is proprietary software protected by the
# patents and laws of the United States of America.
# -----------------------------------------
# Help: support.liveensure.com

import requests
import json
import time
import datetime
import time
import sys
import os

# --------------------------------------------------------------
# Standard API Variables [ DO NOT EDIT ]

apiVersion = "5"
pubHostBase = "https://app.liveensure.com/live-identity"
leHostBase = "https://app.liveensure.com/live-identity"
leHostUrl = leHostBase + "/rest"
stackLocation = "US"
sessionToken = ""
DEBUG = False

# --------------------------------------------------------------
# Developer Variables [ EDIT FOR YOUR ACCOUNT INFO ]

agentId = "d255dcd0-4120-4618-b0be-23510523be85"    # your agentID
apiKey = "1f3863e7-14db-49f2-a172-44e66a1c30d4"     # your apiKey 
apiPass = "NZOxBSgdZYiezmGY"    # your apiPass

# --------------------------------------------------------------


def logger(message):
    st = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
    print str(st) + "|" + str(message)


def liveSessionStart(userId):

    data = {
        'apiVersion':apiVersion,
        'userId':userId,
        'agentId':agentId,
        'apiKey':apiKey
    }

    logger("Starting session ... for " + userId)

    r = requests.put(leHostUrl + "/host/session", json=data)

    if r.status_code == 200:
        value = r.json()
        sessionToken = value['sessionToken']
        msg = "Success " + str(r.status_code)
        logger(msg)
        msg = "Response " + str(sessionToken)
        logger(msg)

        return sessionToken

    else:

        value = r.text
        msg = "Failed: " + str(r.status_code)
        logger(msg)
        msg = "Response=" + str(value)
        logger(msg)

        return "ERROR"


def pollStatus(sessionToken):

    logger("Polling for status ....")
    print(sessionToken)
    if sessionToken == "ERROR":
        logger("Invalid Session Token:" + sessionToken)
        logger("Quitting")
        quit()

    p = requests.get(leHostUrl + "/host/session" + 
                "/" + sessionToken + "/" + agentId)

    if p.status_code == 200:

        pvalue = p.json()
        status = pvalue['sessionStatus']

        msg = "Output: " + status + ":"  + str(p.status_code)
        logger(msg)

        return status

    else:

        msg = "Error: " + str(p.status_code)
        logger(msg)

        pvalue = p.text
        msg = "Response=" + str(pvalue) 
        logger(msg)

        return p.status_code


def addPromptChallenge(question, answer, sessionToken):

    type = "PROMPT"             # Required
    required = "true"           # Required
    fallback = "0"              # Required
    maxAt = "1"                 # Required

    details = {"question":question,
               "answer":answer, 
               "required":required, 
               "fallbackChallengeID":fallback, 
               "maximumAttempts":maxAt}
            
    data = {'sessionToken':str(sessionToken), 
            'challengeType':type, 
            'agentId':agentId, 
            'challengeDetails':details} 

    logger("Adding prompt challenge ... ")

    c = requests.put(leHostUrl + "/host/challenge", json=data)

    # CHECKING STATUS CODE, PRINTING CHALLENGE

    if c.status_code == 200:
        msg =  "Prompt Success: "  + str(c.status_code)
        logger(msg)

        value = c.json()
        msg = "Response=" + str( value['statusMessage'])
        logger(msg)

        return c.status_code

    else:

        msg = "Failed: " + str(c.status_code)
        logger(msg)

        value = c.text
        msg = "Response=" + str(value)
        logger(msg)

        return c.status_code

def addTouchChallenge(orientation,touches):

    type = "HOST_BEHAVIOR"      # Required
    regionCount = "6"           # Grid pattern
    required = "true"           # Required
    fallback = "0"              # Required
    maxAt = "1"                 # Max retries

    details = {"orientation":orientation,
               "touches":touches, 
               "regionCount":regionCount,
               "required":required, 
               "fallbackChallengeID":fallback, 
               "maximumAttempts":maxAt}
            
    data = {'sessionToken':str(sessionToken), 
            'challengeType':type, 
            'agentId':agentId, 
            'challengeDetails':details} 


    logger("Adding a touch challenge ...")

    t = requests.put(leHostUrl + "/host/challenge", json=data)

    if t.status_code == 200:
        msg = "Touch Success: " + str(t.status_code)
        logger(msg)

        value = t.json()
        msg = "Response=" + value['statusMessage']
        logger(msg)

        return t.status_code

    else:

        msg = "Failed: " + str(t.status_code)
        logger(msg)

        value = t.text
        msg = "Response=" + str(value) 
        logger(msg)

        return t.status_code


def addLocChallenge(latitude, longitude, radius):

    type = "LAT_LONG"       # Required
    required = "true"       # Required
    fallback = "0"          # If fail, other challenge
    maxAt = "1"             # Retries

    details = {"latitude":latitude,
               "longitude":longitude, 
               "radius":radius,
               "required":required, 
               "fallbackChallengeID":fallback, 
               "maximumAttempts":maxAt}
            
    data = {'sessionToken':str(sessionToken), 
            'challengeType':type, 
            'agentId':agentId, 
            'challengeDetails':details} 

    logger("Adding location challenge ....")

    l = requests.put(leHostUrl + "/host/challenge", json=data)


    if l.status_code == 200:
        msg = "Loc Success: " + str(l.status_code)
        logger(msg)

        value = l.json()
        msg = "Response=" + str(value['statusMessage'])
        logger(msg)

        return l.status_code

    else:

        msg = "Failed: " + str(l.status_code)
        logger(msg)

        value = l.text
        msg = "Response=" + str(value) 
        logger(msg)


def getAuthObj(type, sessionToken):

    if sessionToken == "ERROR":
        logger("Invalid SessionToken " + sessionToken)
        logger("Quitting.")
        quit()

    qurl = leHostBase + "/QR?w=240&sessionToken=" + sessionToken
    furl = leHostBase + "/launcher?sessionToken=" + sessionToken
    lirl = leHostBase + "/launcher?sessionToken=" + sessionToken + "&light=1"
    lurl = "liveensure://?sessionToken=" + sessionToken +                                   "&status=" + leHostBase + "/rest"

    logger("Returning " + type + " Auth Object")

    if type == "IMG":
        logger(qurl)
        return(qurl)
    elif type == "COMBO":
        logger(furl)
        return(furl)
    elif type == "LIGHT":
        logger(lirl)
        return(lirl)
    elif type == "LINK":
        logger(lurl)
        return(lurl)
    else:
        logger("NO TOKEN")
        return "NOTOKEN"


if __name__ == "__main__":

    # 1.Start the Session for userId
    userId = "kap.sni@gmail.com"

    sessionToken = liveSessionStart(userId)

    # 2. Add Challenges you want

    # Prompt Challenge / Variables
    # question = "Enter Pin"
    # answer = "1234"

    # status = addPromptChallenge(question, answer)

    # Touch Challenge / Variables
    orientation = "2"
    touches = "5"

    status = addTouchChallenge(orientation, touches)

    # # Location Challenge / Variables

    # # ex. Menlo Park, CA USA / 10km Radius
    # latitude = "37.44787423894324"
    # longitude = "-122.18313123661915" 
    # radius = "10"

    # status = addLocChallenge(latitude, longitude, radius)

    # 3. Get/show the Code/link

    # Type: IMG, COMBO, LIGHT, LINK
    type = "IMG"

    object = getAuthObj(type, sessionToken)

    # 4. Pause for you to copy/paste or scan/tap to test

    print "-------------------------------------------"
    response = raw_input("Do you have the code/link?")
    print "-------------------------------------------"

    # 5. Poll for Status

    status = pollStatus(sessionToken)
