from django.shortcuts import render
from django.http import HttpResponse

from .live_api import liveSessionStart, addPromptChallenge, getAuthObj, pollStatus

def main(request):
    return render(request, 'live/main.html')

def deviceAuthenticate(request):
    if(request.method == "POST"):
        sessionToken = liveSessionStart(request.POST['email'])
        if(sessionToken != "ERROR"):
            img = getAuthObj('IMG', sessionToken)
            return render(request, 'live/objectpoll.html', {"sessionToken" :sessionToken, "object": img})
        else:
            return HttpResponse("Error creating session")
    else:
        return render(request, 'live/session.html')

def challengeAuthenticate(request):
    if(request.method == 'POST'):
        sessionToken = liveSessionStart(request.POST['email'])
        if(sessionToken != "ERROR"):
            status = addPromptChallenge(request.POST['question'], request.POST['answer'], sessionToken)
            if(status == 200):
                img = getAuthObj('IMG', sessionToken)
                return render(request, 'live/objectpoll.html',{"sessionToken": sessionToken, "object": img})
            else: 
                return HttpResponse("Error creating challenge")
        else:
            return HttpResponse("Error creating session")
    else:
        return render(request, 'live/promptChallenge.html')


def poll_status(request):
    if(request.method == 'POST'):
        d = str(request.POST.get('sessionToken'))
        status = pollStatus(d)
        return HttpResponse(status)
